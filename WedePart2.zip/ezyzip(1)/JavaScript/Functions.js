var MoreMenusIcon = document.getElementById('MoreMenusIcon');

MoreMenusIcon.addEventListener('click', function ToggleMenu() {
    alert('hello world')
})